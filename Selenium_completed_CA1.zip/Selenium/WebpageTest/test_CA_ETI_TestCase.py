import os
import pytest
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

#1
def test_admin_without_password():
    driver = webdriver.Chrome()
    driver.maximize_window()
    driver.get('localhost:8000/admin')
    elem = driver.find_element_by_name("username")
    elem.clear()
    elem.send_keys("kelvi")
    elem.send_keys(Keys.RETURN)
    elem = driver.find_element_by_name("password")
    elem.clear()
    elem.send_keys("")
    elem.send_keys(Keys.RETURN)
    assert driver.find_element_by_css_selector("input:invalid")
#2
def test_admin_without_username():
    driver = webdriver.Chrome()
    driver.maximize_window()
    driver.get('localhost:8000/admin')
    elem = driver.find_element_by_name("username")
    elem.clear()
    elem.send_keys("")
    elem.send_keys(Keys.RETURN)
    elem = driver.find_element_by_name("password")
    elem.clear()
    elem.send_keys("")
    elem.send_keys(Keys.RETURN)
    assert driver.find_element_by_css_selector("input:invalid")
#3    
def test_admin_with_wrong_password():
    driver = webdriver.Chrome()
    driver.maximize_window()
    driver.get('localhost:8000/admin')
    elem = driver.find_element_by_name("username")
    elem.clear()
    elem.send_keys("kelvi")
    elem.send_keys(Keys.RETURN)
    elem = driver.find_element_by_name("password")
    elem.clear()
    elem.send_keys("wrongpw")
    elem.send_keys(Keys.RETURN)
    assert"Log in | Django site admin" in driver.title
#4
def test_admin_login():
    driver = webdriver.Chrome()
    driver.maximize_window()
    driver.get('localhost:8000/admin')
    elem = driver.find_element_by_name("username")
    elem.clear()
    elem.send_keys("kelvi")
    elem.send_keys(Keys.RETURN)
    elem = driver.find_element_by_name("password")
    elem.clear()
    elem.send_keys("17T89y98")
    elem.send_keys(Keys.RETURN)
    assert"Site administration | Django site admin" in driver.title
#5
def test_blog_submit():
    driver = webdriver.Chrome()
    driver.maximize_window()
    driver.get('localhost:8000/blog/')
    driver.find_element_by_link_text("Projects done to date").click()
    name = driver.find_element_by_name("author")
    name.send_keys('Testing123')
    comment = driver.find_element_by_name("body")
    comment.send_keys('This shall be my comment testinggggggggg.')
    submit = driver.find_element_by_xpath('/html/body/div/div/form/button').click()
    result = ("Projects done to date")
    assert result == driver.find_element_by_tag_name('h1').text
#6
def test_blog_submit_without_author():
    driver = webdriver.Chrome()
    driver.maximize_window()
    driver.get('localhost:8000/blog/')
    driver.find_element_by_link_text("Projects done to date").click()
    name = driver.find_element_by_name("author")
    name.send_keys('')
    comment = driver.find_element_by_name("body")
    comment.send_keys('This shall be my comment testinggggggggg.')
    submit = driver.find_element_by_xpath('/html/body/div/div/form/button').click()
    assert driver.find_element_by_css_selector("input:invalid")
#7
def test_blog_submit_without_body():
    driver = webdriver.Chrome()
    driver.maximize_window()
    driver.get('localhost:8000/blog/')
    driver.find_element_by_link_text("Projects done to date").click()
    name = driver.find_element_by_name("author")
    name.send_keys('Testing123')
    comment = driver.find_element_by_name("body")
    comment.send_keys("")
    submit = driver.find_element_by_xpath('/html/body/div/div/form/button').click()
    assert driver.find_element_by_css_selector("textarea:invalid")
#8
def test_project_click_readmore():
    driver = webdriver.Chrome()
    driver.maximize_window()
    driver.get('localhost:8000/projects')
    elem = driver.find_element_by_class_name("btn.btn-primary")
    elem.click();
    result = ("My First Project")
    assert result == driver.find_element_by_tag_name('h1').text
#9    
def test_projects_click_blog():
    driver = webdriver.Chrome()
    driver.maximize_window()
    driver.get('localhost:8000/projects')
    elem = driver.find_element_by_name("blog")
    elem.click();
    result = ("Blog Index")
    assert result == driver.find_element_by_tag_name('h1').text
#10
def test_blog_click_projects():
    driver = webdriver.Chrome()
    driver.maximize_window()
    driver.get('localhost:8000/blog')
    elem = driver.find_element_by_name("home")
    elem.click();
    result = ("My Portfolio")
    assert result == driver.find_element_by_tag_name('h1').text
